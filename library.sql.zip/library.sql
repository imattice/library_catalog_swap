-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 27, 2015 at 11:53 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--
CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library`;

-- --------------------------------------------------------

--
-- Table structure for table `authors_books`
--

CREATE TABLE IF NOT EXISTS `authors_books` (
  `id` bigint(20) unsigned NOT NULL,
  `authors_id` int(11) DEFAULT NULL,
  `books_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors_books`
--

INSERT INTO `authors_books` (`id`, `authors_id`, `books_id`) VALUES
(1, 5, 4),
(2, 10, 28),
(3, 11, 29),
(4, 12, 30),
(5, 13, 31),
(6, 14, 32),
(7, 15, 33),
(8, 16, 34),
(9, 17, 35),
(10, 18, 36),
(11, 19, 37);

-- --------------------------------------------------------

--
-- Table structure for table `t_authors`
--

CREATE TABLE IF NOT EXISTS `t_authors` (
  `id` int(11) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_authors`
--

INSERT INTO `t_authors` (`id`, `last_name`, `first_name`) VALUES
(1, '', 'Psych'),
(2, '', ''),
(3, '', ''),
(4, 'tee', 'me'),
(5, 'tee', 'me'),
(6, 'tee', 'me'),
(7, 'Testing', 'Testing'),
(8, 'Crichton', 'Michael'),
(9, 'Christ', 'Jesus H'),
(10, 'Cr', 'Michael'),
(11, 'Crichton', 'Michael'),
(12, 'Crichton', 'Michael'),
(13, 'Crichton', 'Michael'),
(14, 'Crichton', 'Michael'),
(15, 'Crichton', 'Michael'),
(16, 'Crichton', 'Michael'),
(17, 'Crichton', 'Michael'),
(18, 'Crichton', 'Michael'),
(19, 'Crichton', 'Michael');

-- --------------------------------------------------------

--
-- Table structure for table `t_books`
--

CREATE TABLE IF NOT EXISTS `t_books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_patrons`
--

CREATE TABLE IF NOT EXISTS `t_patrons` (
  `name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors_books`
--
ALTER TABLE `authors_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `t_authors`
--
ALTER TABLE `t_authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_books`
--
ALTER TABLE `t_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_patrons`
--
ALTER TABLE `t_patrons`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors_books`
--
ALTER TABLE `authors_books`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `t_authors`
--
ALTER TABLE `t_authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `t_books`
--
ALTER TABLE `t_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
